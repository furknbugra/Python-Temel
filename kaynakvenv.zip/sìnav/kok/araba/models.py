from django.db import models

# Create your models here.

class arabalar(models.Model):
    adi = models.CharField(max_length=50)
    uretimyeri = models.CharField(max_length=50)
    motorgucu = models.IntegerField()
    yakit = models.CharField(max_length=50)
    uretimyili = models.DateField()