from django.shortcuts import render,redirect
from .models import arabalar
from .forms import arabaForm

# Create your views here.

def merhaba(request):
    liste = arabalar.objects.all()
    return render(request, "araba/giris.html", {"araba": liste})

def ekle(request):
    if request.method == "POST":
        form = arabaForm(data=request.POST)
        if form.is_valid():
            form.save()
            return redirect("/")
    else:
        form = arabaForm
    return render(request, "araba/ekle.html", {"form": form})

def sil(request,id):
    kayit = arabalar.objects.get(id=id)
    kayit.delete()
    return redirect("/")