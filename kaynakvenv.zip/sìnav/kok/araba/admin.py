from django.contrib import admin
from .models import arabalar    

# Register your models here.

@admin.register(arabalar)
class arabaAdmin(admin.ModelAdmin):
    list_display = ("adi", "uretimyeri")